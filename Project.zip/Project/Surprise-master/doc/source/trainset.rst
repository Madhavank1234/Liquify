.. _trainset:

Trainset class
==============

.. autoclass:: surprise.Trainset
    :members:
