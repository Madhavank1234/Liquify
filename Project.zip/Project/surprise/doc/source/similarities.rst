.. _similarities:

similarities module
===================

.. automodule:: surprise.similarities
    :members:
    :exclude-members: compute_mean_diff
    :show-inheritance:
